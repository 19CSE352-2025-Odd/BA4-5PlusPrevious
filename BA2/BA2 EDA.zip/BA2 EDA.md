#### Summary Statistics 


The pandas package offers several methods that assist in summarizing data. The
DataFrame method describe() gives an overview of the entire set of variables in the data.
The methods mean(), std(), min(), max(), median(), and len() are also very helpful for
learning about the characteristics of each variable. First, they give us information about
the scale and type of values that the variable takes. The min and max statistics can be
used to detect extreme values that might be errors. The mean and median give a sense of
the central values of that variable, and a large deviation between the two also indicates
skew. The standard deviation gives a sense of how dispersed the data are (relative to the
mean). Further options, such as the combination of .isnull().sum(), which gives the
number of null values, can tell us about missing values.

(1) incorporating domain knowledge to remove or combine categories, 
(2) using data summaries to detect information overlap between variables
(and remove or combine redundant variables or categories), 
(3) using data conversion techniques such as converting categorical variables into numerical variables


```python
pip install seaborn
```

    Requirement already satisfied: seaborn in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (0.13.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.20 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from seaborn) (2.3.0)
    Requirement already satisfied: pandas>=1.2 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from seaborn) (2.3.0)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.4 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from seaborn) (3.10.3)
    Requirement already satisfied: contourpy>=1.0.1 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.3.2)
    Requirement already satisfied: cycler>=0.10 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (4.58.4)
    Requirement already satisfied: kiwisolver>=1.3.1 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.4.8)
    Requirement already satisfied: packaging>=20.0 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (25.0)
    Requirement already satisfied: pillow>=8 in /opt/homebrew/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (11.2.1)
    Requirement already satisfied: pyparsing>=2.3.1 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (3.2.3)
    Requirement already satisfied: python-dateutil>=2.7 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from pandas>=1.2->seaborn) (2025.2)
    Requirement already satisfied: tzdata>=2022.7 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from pandas>=1.2->seaborn) (2025.2)
    Requirement already satisfied: six>=1.5 in /opt/homebrew/Cellar/jupyterlab/4.4.3_2/libexec/lib/python3.13/site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.4->seaborn) (1.17.0)
    Note: you may need to restart the kernel to use updated packages.



```python
import numpy as np
import pandas as pd
from sklearn import preprocessing
import matplotlib.pylab as plt
```

It is likely that subsets of variables are highly correlated with each other.
Including highly correlated variables in a classification or prediction model, or including
variables that are unrelated to the outcome of interest, can lead to overfitting, and
accuracy and reliability can suffer. A large number of variables also poses computational
problems for some supervised as well as unsupervised algorithms (aside from questions
of correlation). In model deployment, superfluous variables can increase costs due to the
collection and processing of these variables.


```python
bostonHousing_df = pd.read_csv('https://raw.githubusercontent.com/reisanar/datasets/master/BostonHousing.csv')
```


```python
# Description of Variables in the Boston Housing Dataset
# CRIM Crime rate
# ZN Percentage of residential land zoned for lots over 25,000 ft2
# INDUS Percentage of land occupied by nonretail business
# CHAS Does tract bound Charles River? (= 1 if tract bounds river, = 0 otherwise)
# NOX Nitric oxide concentration (parts per 10 million)
# RM Average number of rooms per dwelling
# AGE Percentage of owner-occupied units built prior to 1940
# DIS Weighted distances to five Boston employment centers
# RAD Index of accessibility to radial highways
# TAX Full-value property tax rate per $10,000s
# PTRATIO Pupil-to-teacher ratio by town
# LSTAT Percentage of lower status of the population
# MEDV Median value of owner-occupied homes in $1000
# CAT.MEDV Is median value of owner-occupied homes in tract above $30,000
# (CAT.MEDV = 1) or not (CAT.MEDV = 0)?
```


```python
bostonHousing_df = bostonHousing_df.rename(columns={"CAT. MEDV": "CAT_MEDV"})
bostonHousing_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>LSTAT</th>
      <th>MEDV</th>
      <th>CAT_MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296</td>
      <td>15.3</td>
      <td>4.98</td>
      <td>24.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>9.14</td>
      <td>21.6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>4.03</td>
      <td>34.7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>2.94</td>
      <td>33.4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>5.33</td>
      <td>36.2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
bostonHousing_df = bostonHousing_df.rename(columns={"CAT. MEDV": "CAT_MEDV"})
bostonHousing_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>LSTAT</th>
      <th>MEDV</th>
      <th>CAT_MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296</td>
      <td>15.3</td>
      <td>4.98</td>
      <td>24.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>9.14</td>
      <td>21.6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242</td>
      <td>17.8</td>
      <td>4.03</td>
      <td>34.7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>2.94</td>
      <td>33.4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222</td>
      <td>18.7</td>
      <td>5.33</td>
      <td>36.2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
bostonHousing_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>LSTAT</th>
      <th>MEDV</th>
      <th>CAT_MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
      <td>506.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3.613524</td>
      <td>11.363636</td>
      <td>11.136779</td>
      <td>0.069170</td>
      <td>0.554695</td>
      <td>6.284634</td>
      <td>68.574901</td>
      <td>3.795043</td>
      <td>9.549407</td>
      <td>408.237154</td>
      <td>18.455534</td>
      <td>12.653063</td>
      <td>22.532806</td>
      <td>0.166008</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8.601545</td>
      <td>23.322453</td>
      <td>6.860353</td>
      <td>0.253994</td>
      <td>0.115878</td>
      <td>0.702617</td>
      <td>28.148861</td>
      <td>2.105710</td>
      <td>8.707259</td>
      <td>168.537116</td>
      <td>2.164946</td>
      <td>7.141062</td>
      <td>9.197104</td>
      <td>0.372456</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.006320</td>
      <td>0.000000</td>
      <td>0.460000</td>
      <td>0.000000</td>
      <td>0.385000</td>
      <td>3.561000</td>
      <td>2.900000</td>
      <td>1.129600</td>
      <td>1.000000</td>
      <td>187.000000</td>
      <td>12.600000</td>
      <td>1.730000</td>
      <td>5.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.082045</td>
      <td>0.000000</td>
      <td>5.190000</td>
      <td>0.000000</td>
      <td>0.449000</td>
      <td>5.885500</td>
      <td>45.025000</td>
      <td>2.100175</td>
      <td>4.000000</td>
      <td>279.000000</td>
      <td>17.400000</td>
      <td>6.950000</td>
      <td>17.025000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.256510</td>
      <td>0.000000</td>
      <td>9.690000</td>
      <td>0.000000</td>
      <td>0.538000</td>
      <td>6.208500</td>
      <td>77.500000</td>
      <td>3.207450</td>
      <td>5.000000</td>
      <td>330.000000</td>
      <td>19.050000</td>
      <td>11.360000</td>
      <td>21.200000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3.677083</td>
      <td>12.500000</td>
      <td>18.100000</td>
      <td>0.000000</td>
      <td>0.624000</td>
      <td>6.623500</td>
      <td>94.075000</td>
      <td>5.188425</td>
      <td>24.000000</td>
      <td>666.000000</td>
      <td>20.200000</td>
      <td>16.955000</td>
      <td>25.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>88.976200</td>
      <td>100.000000</td>
      <td>27.740000</td>
      <td>1.000000</td>
      <td>0.871000</td>
      <td>8.780000</td>
      <td>100.000000</td>
      <td>12.126500</td>
      <td>24.000000</td>
      <td>711.000000</td>
      <td>22.000000</td>
      <td>37.970000</td>
      <td>50.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Compute mean, standard deviation, min, max, median, length, and missing values of
# CRIM
print('Mean : ', bostonHousing_df.CRIM.mean())
print('Std. dev : ', bostonHousing_df.CRIM.std())
print('Min : ', bostonHousing_df.CRIM.min())
print('Max : ', bostonHousing_df.CRIM.max())
print('Median : ', bostonHousing_df.CRIM.median())
print('Length : ', len(bostonHousing_df.CRIM))
print('Number of missing values : ', bostonHousing_df.CRIM.isnull().sum())
```

    Mean :  3.613523557312254
    Std. dev :  8.60154510533249
    Min :  0.00632
    Max :  88.9762
    Median :  0.25651
    Length :  506
    Number of missing values :  0



```python
# Compute mean, standard dev., min, max, median, length, and missing values for all
# variables
pd.DataFrame({'mean': bostonHousing_df.mean(),
'sd': bostonHousing_df.std(),
'min': bostonHousing_df.min(),
'max': bostonHousing_df.max(),
'median': bostonHousing_df.median(),
'length': len(bostonHousing_df),
'miss.val': bostonHousing_df.isnull().sum(),
})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean</th>
      <th>sd</th>
      <th>min</th>
      <th>max</th>
      <th>median</th>
      <th>length</th>
      <th>miss.val</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>CRIM</th>
      <td>3.613524</td>
      <td>8.601545</td>
      <td>0.00632</td>
      <td>88.9762</td>
      <td>0.25651</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ZN</th>
      <td>11.363636</td>
      <td>23.322453</td>
      <td>0.00000</td>
      <td>100.0000</td>
      <td>0.00000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>INDUS</th>
      <td>11.136779</td>
      <td>6.860353</td>
      <td>0.46000</td>
      <td>27.7400</td>
      <td>9.69000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>CHAS</th>
      <td>0.069170</td>
      <td>0.253994</td>
      <td>0.00000</td>
      <td>1.0000</td>
      <td>0.00000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>NOX</th>
      <td>0.554695</td>
      <td>0.115878</td>
      <td>0.38500</td>
      <td>0.8710</td>
      <td>0.53800</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>RM</th>
      <td>6.284634</td>
      <td>0.702617</td>
      <td>3.56100</td>
      <td>8.7800</td>
      <td>6.20850</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AGE</th>
      <td>68.574901</td>
      <td>28.148861</td>
      <td>2.90000</td>
      <td>100.0000</td>
      <td>77.50000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>DIS</th>
      <td>3.795043</td>
      <td>2.105710</td>
      <td>1.12960</td>
      <td>12.1265</td>
      <td>3.20745</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>RAD</th>
      <td>9.549407</td>
      <td>8.707259</td>
      <td>1.00000</td>
      <td>24.0000</td>
      <td>5.00000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>TAX</th>
      <td>408.237154</td>
      <td>168.537116</td>
      <td>187.00000</td>
      <td>711.0000</td>
      <td>330.00000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>PTRATIO</th>
      <td>18.455534</td>
      <td>2.164946</td>
      <td>12.60000</td>
      <td>22.0000</td>
      <td>19.05000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>LSTAT</th>
      <td>12.653063</td>
      <td>7.141062</td>
      <td>1.73000</td>
      <td>37.9700</td>
      <td>11.36000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>MEDV</th>
      <td>22.532806</td>
      <td>9.197104</td>
      <td>5.00000</td>
      <td>50.0000</td>
      <td>21.20000</td>
      <td>506</td>
      <td>0</td>
    </tr>
    <tr>
      <th>CAT_MEDV</th>
      <td>0.166008</td>
      <td>0.372456</td>
      <td>0.00000</td>
      <td>1.0000</td>
      <td>0.00000</td>
      <td>506</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#summarize relationships between two or more variables. For numerical
#variables, we can compute a complete matrix of correlations between each pair of
#variables, using the pandas method corr().We see that most correlations are low and that many are
#negative. Recall also the visual display of a correlation matrix via a heatmap .
```


      Cell In[10], line 1
        summarize relationships between two or more variables. For numerical
                  ^
    SyntaxError: invalid syntax




```python
bostonHousing_df.corr().round(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>LSTAT</th>
      <th>MEDV</th>
      <th>CAT_MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>CRIM</th>
      <td>1.00</td>
      <td>-0.20</td>
      <td>0.41</td>
      <td>-0.06</td>
      <td>0.42</td>
      <td>-0.22</td>
      <td>0.35</td>
      <td>-0.38</td>
      <td>0.63</td>
      <td>0.58</td>
      <td>0.29</td>
      <td>0.46</td>
      <td>-0.39</td>
      <td>-0.15</td>
    </tr>
    <tr>
      <th>ZN</th>
      <td>-0.20</td>
      <td>1.00</td>
      <td>-0.53</td>
      <td>-0.04</td>
      <td>-0.52</td>
      <td>0.31</td>
      <td>-0.57</td>
      <td>0.66</td>
      <td>-0.31</td>
      <td>-0.31</td>
      <td>-0.39</td>
      <td>-0.41</td>
      <td>0.36</td>
      <td>0.37</td>
    </tr>
    <tr>
      <th>INDUS</th>
      <td>0.41</td>
      <td>-0.53</td>
      <td>1.00</td>
      <td>0.06</td>
      <td>0.76</td>
      <td>-0.39</td>
      <td>0.64</td>
      <td>-0.71</td>
      <td>0.60</td>
      <td>0.72</td>
      <td>0.38</td>
      <td>0.60</td>
      <td>-0.48</td>
      <td>-0.37</td>
    </tr>
    <tr>
      <th>CHAS</th>
      <td>-0.06</td>
      <td>-0.04</td>
      <td>0.06</td>
      <td>1.00</td>
      <td>0.09</td>
      <td>0.09</td>
      <td>0.09</td>
      <td>-0.10</td>
      <td>-0.01</td>
      <td>-0.04</td>
      <td>-0.12</td>
      <td>-0.05</td>
      <td>0.18</td>
      <td>0.11</td>
    </tr>
    <tr>
      <th>NOX</th>
      <td>0.42</td>
      <td>-0.52</td>
      <td>0.76</td>
      <td>0.09</td>
      <td>1.00</td>
      <td>-0.30</td>
      <td>0.73</td>
      <td>-0.77</td>
      <td>0.61</td>
      <td>0.67</td>
      <td>0.19</td>
      <td>0.59</td>
      <td>-0.43</td>
      <td>-0.23</td>
    </tr>
    <tr>
      <th>RM</th>
      <td>-0.22</td>
      <td>0.31</td>
      <td>-0.39</td>
      <td>0.09</td>
      <td>-0.30</td>
      <td>1.00</td>
      <td>-0.24</td>
      <td>0.21</td>
      <td>-0.21</td>
      <td>-0.29</td>
      <td>-0.36</td>
      <td>-0.61</td>
      <td>0.70</td>
      <td>0.64</td>
    </tr>
    <tr>
      <th>AGE</th>
      <td>0.35</td>
      <td>-0.57</td>
      <td>0.64</td>
      <td>0.09</td>
      <td>0.73</td>
      <td>-0.24</td>
      <td>1.00</td>
      <td>-0.75</td>
      <td>0.46</td>
      <td>0.51</td>
      <td>0.26</td>
      <td>0.60</td>
      <td>-0.38</td>
      <td>-0.19</td>
    </tr>
    <tr>
      <th>DIS</th>
      <td>-0.38</td>
      <td>0.66</td>
      <td>-0.71</td>
      <td>-0.10</td>
      <td>-0.77</td>
      <td>0.21</td>
      <td>-0.75</td>
      <td>1.00</td>
      <td>-0.49</td>
      <td>-0.53</td>
      <td>-0.23</td>
      <td>-0.50</td>
      <td>0.25</td>
      <td>0.12</td>
    </tr>
    <tr>
      <th>RAD</th>
      <td>0.63</td>
      <td>-0.31</td>
      <td>0.60</td>
      <td>-0.01</td>
      <td>0.61</td>
      <td>-0.21</td>
      <td>0.46</td>
      <td>-0.49</td>
      <td>1.00</td>
      <td>0.91</td>
      <td>0.46</td>
      <td>0.49</td>
      <td>-0.38</td>
      <td>-0.20</td>
    </tr>
    <tr>
      <th>TAX</th>
      <td>0.58</td>
      <td>-0.31</td>
      <td>0.72</td>
      <td>-0.04</td>
      <td>0.67</td>
      <td>-0.29</td>
      <td>0.51</td>
      <td>-0.53</td>
      <td>0.91</td>
      <td>1.00</td>
      <td>0.46</td>
      <td>0.54</td>
      <td>-0.47</td>
      <td>-0.27</td>
    </tr>
    <tr>
      <th>PTRATIO</th>
      <td>0.29</td>
      <td>-0.39</td>
      <td>0.38</td>
      <td>-0.12</td>
      <td>0.19</td>
      <td>-0.36</td>
      <td>0.26</td>
      <td>-0.23</td>
      <td>0.46</td>
      <td>0.46</td>
      <td>1.00</td>
      <td>0.37</td>
      <td>-0.51</td>
      <td>-0.44</td>
    </tr>
    <tr>
      <th>LSTAT</th>
      <td>0.46</td>
      <td>-0.41</td>
      <td>0.60</td>
      <td>-0.05</td>
      <td>0.59</td>
      <td>-0.61</td>
      <td>0.60</td>
      <td>-0.50</td>
      <td>0.49</td>
      <td>0.54</td>
      <td>0.37</td>
      <td>1.00</td>
      <td>-0.74</td>
      <td>-0.47</td>
    </tr>
    <tr>
      <th>MEDV</th>
      <td>-0.39</td>
      <td>0.36</td>
      <td>-0.48</td>
      <td>0.18</td>
      <td>-0.43</td>
      <td>0.70</td>
      <td>-0.38</td>
      <td>0.25</td>
      <td>-0.38</td>
      <td>-0.47</td>
      <td>-0.51</td>
      <td>-0.74</td>
      <td>1.00</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>CAT_MEDV</th>
      <td>-0.15</td>
      <td>0.37</td>
      <td>-0.37</td>
      <td>0.11</td>
      <td>-0.23</td>
      <td>0.64</td>
      <td>-0.19</td>
      <td>0.12</td>
      <td>-0.20</td>
      <td>-0.27</td>
      <td>-0.44</td>
      <td>-0.47</td>
      <td>0.79</td>
      <td>1.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
Heatmaps: Visualizing Correlations and Missing Values
A heatmap is a graphical display of numerical data where color is used to denote values.
In a data mining context, heatmaps are especially useful for two purposes: for visualizing
correlation tables and for visualizing missing values in the data. In both cases, the
information is conveyed in a two-dimensional table. A correlation table for p variables has
p rows and p columns. A data table contains p columns (variables) and n rows
(observations). If the number of rows is huge, then a subset can be used. In both cases, it
is much easier and faster to scan the color-coding rather than the values. Note that
heatmaps are useful when examining a large number of values, but they are not a
replacement for more precise graphical display, such as bar charts, because color
differences cannot be perceived accurately.
```


```python
## simple heatmap of correlations (without values)
corr = bostonHousing_df.corr()
```


```python
import seaborn as sns
```


```python
sns.heatmap(corr, xticklabels=corr.columns, yticklabels=corr.columns)
```




    <Axes: >




    
![png](output_18_1.png)
    



```python
# Change the colormap to a divergent scale and fix the range of the colormap
#sns.heatmap(corr, xticklabels=corr.columns, yticklabels=corr.columns, vmin=-1,vmax=1, cmap = 'RdBu')
# Include information about values (example demonstrate how to control the size of  the plot
fig, ax = plt.subplots()
fig.set_size_inches(11, 7)
sns.heatmap(corr, annot=True, fmt='.1f', cmap='RdBu', center=0, ax=ax)
```




    <Axes: >




    
![png](output_19_1.png)
    



```python
Aggregation and Pivot Tables
```


```python
bostonHousing_df.CHAS.value_counts()
```




    CHAS
    0    471
    1     35
    Name: count, dtype: int64



code for aggregating MEDV by CHAS and RM
Create bins of size 1 for variable using the method pd.cut. By default, the method creates a categorical variable 
The argument labels=False determines integers instead, e.g. 6.
bostonHousing_df["RM_bin"] = pd.cut(bostonHousing_df.RM, range(0, 10), labels=False)
Compute the average of MEDV by (binned) RM and CHAS. 
First group the data frame using the groupby method, 
then restrict the analysis to MEDV and determine mean for each group.
bostonHousing_df.groupby([’RM_bin’, ’CHAS’])[’MEDV’].mean()


```python
 bostonHousing_df["RM_bin"]= pd.cut(bostonHousing_df.RM, range(0, 10),labels=False) # range is bin range
```


```python
bostonHousing_df["RM_bin"]
```




    0      6
    1      6
    2      7
    3      6
    4      7
          ..
    501    6
    502    6
    503    6
    504    6
    505    6
    Name: RM_bin, Length: 506, dtype: int64




```python
bostonHousing_df.groupby(["RM_bin", "CHAS"])["MEDV"].mean()
```




    RM_bin  CHAS
    3       0       25.300000
    4       0       15.407143
    5       0       17.200000
            1       22.218182
    6       0       21.769170
            1       25.918750
    7       0       35.964444
            1       44.066667
    8       0       45.700000
            1       35.950000
    Name: MEDV, dtype: float64



Another useful method is pivot_table() in the pandas package, that allows the creation of pivot tables by reshaping the data by the aggregating variables of our choice. For example, code below computes the average of MEDV by CHAS and RM and presents it as a pivot table.


```python
pd.pivot_table(bostonHousing_df, values="MEDV", index=["RM_bin"], columns= ["CHAS"],aggfunc=np.mean, margins=True)
```


```python
===End EDA===
```
